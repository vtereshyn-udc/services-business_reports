const element = document.querySelector('kat-radiobutton[kat-aria-label="Comprehensive View"]');
if (element) {
    element.click();
}