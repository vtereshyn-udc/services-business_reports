import os
import json
from pathlib import Path
from dotenv import load_dotenv


class Config:
    def __init__(self):
        self.config_path: Path = Path(__file__).resolve().parent
        self.project_path: Path = Path(self.config_path).parent
        self.env_path: str = os.path.join(self.config_path, ".env")
        self.screenshots_path: str = os.path.join(self.project_path, "sources", "screenshots")
        self.db_path: str = os.path.join(self.project_path, "database", "sqlite.db")
        self.sms_path: str = os.path.join(self.config_path, "sms.json")
        self.js_path: str = os.path.join(self.project_path, "sources", "js")
        self.reports_path: str = os.path.join(self.project_path, "reports")
        self.service_account_path: str = os.path.join(self.config_path, "google_credentials.json")
        self.main_script_path: str = os.path.join(self.project_path, "main.py")
        self.logs_path: str = os.path.join(self.project_path, "logs")
        self.read_config()
        load_dotenv(dotenv_path=self.env_path)

    def __getattr__(self, attr: str) -> str:
        return os.getenv(attr)

    def get_password(self, username: str) -> str:
        return self.__getattr__(attr=username.upper())

    def get_auth(self, user_id: str) -> str:
        username: str = self.USERS[user_id]["username"]
        return self.__getattr__(attr=f"{username}_AUTH".upper())

    def read_config(self) -> None:
        files: list = [file for file in os.listdir(self.config_path) if file.endswith(".json")]
        for file in files:
            file_path: str = os.path.join(self.config_path, file)
            with open(file=file_path, mode="r", encoding="utf-8") as cfg:
                setattr(self, file[:-5].upper(), json.loads(cfg.read()))

        if hasattr(self, "USERS"):
            users: list = getattr(self, "USERS")
            if isinstance(users, list) and any([u.get("id") for u in users]):
                setattr(self, "USERS", {user.get("id"): user for user in users})


config: Config = Config()
